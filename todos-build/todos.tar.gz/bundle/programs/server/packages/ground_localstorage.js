(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['ground:localstorage'] = {};

})();

//# sourceMappingURL=ground_localstorage.js.map
