(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var MongoInternals = Package.mongo.MongoInternals;
var Mongo = Package.mongo.Mongo;
var DDP = Package.ddp.DDP;
var DDPServer = Package.ddp.DDPServer;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['raix:stubfence'] = {};

})();

//# sourceMappingURL=raix_stubfence.js.map
